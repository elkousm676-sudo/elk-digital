import { Smartphone, Target, DollarSign, BellRing, UserCheck, ShieldCheck } from "lucide-react";

export default function WhyUs() {
  const points = [
    {
      icon: <Smartphone className="w-6 h-6 text-red-500" />,
      title: "Optimisation Mobile Totale (3G / 4G)",
      description: "Au Maroc, plus de 85% des commandes e-commerce se font sur mobile. Je structure chaque pixel et compresse chaque image pour que votre site s'ouvre instantanément, même avec une connexion internet faible."
    },
    {
      icon: <Target className="w-6 h-6 text-red-500" />,
      title: "Pixels publicitaires & API de conversion robustes",
      description: "Ne gaspillez plus votre budget publicitaire Meta ou TikTok. Grâce à l'intégration des API côté serveur (CAPI), les événements d'achat s'enregistrent fidèlement à 100%, optimisant vos coûts d'acquisition."
    },
    {
      icon: <DollarSign className="w-6 h-6 text-red-500" />,
      title: "Zéro Frais Mensuels d'Applications Tierces",
      description: "Au lieu d'installer 10 applications payantes pour les avis, le bouton WhatsApp collant et les urgences de stock (qui ralentissent votre site), j'injecte directement ces fonctionnalités en code CSS/JS natif gratuit."
    },
    {
      icon: <BellRing className="w-6 h-6 text-red-500" />,
      title: "Parcours Spécial Cash On Delivery (COD)",
      description: "Formulaire d'achat ultra simplifié, liste déroulante automatisée des villes marocaines, réduction du taux d'abandon du panier et relances pré-configurées pour booster votre taux de livraison effectif."
    },
    {
      icon: <UserCheck className="w-6 h-6 text-red-500" />,
      title: "Communication Directe de Humain à Humain",
      description: "Pas de standard d'agence injoignable ou de chef de projet intermédiaire. Vous parlez en direct avec moi (Amine) par téléphone ou WhatsApp. Les modifications se font ainsi en temps réel."
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-red-500" />,
      title: "Livraison Clean & Prête à l'Emploi",
      description: "À la livraison, vous recevez une boutique 100% fonctionnelle, des fiches produits prêtes à recevoir du trafic, et des tutoriels vidéos simples pour gérer vos commandes de manière autonome."
    }
  ];

  return (
    <section id="why-us" className="bg-zinc-950 py-24 border-b border-zinc-900 relative">
      {/* Background visual element */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-red-600/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Title */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <div className="inline-block bg-red-600/10 border border-red-500/20 text-red-400 font-mono font-bold text-xs uppercase px-3.5 py-1 rounded-full">
            Pourquoi Me Faire Confiance ?
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            La Différence <span className="text-red-500 font-black">ELK-DIGITAL</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base">
            De nombreux prestataires se contentent de dupliquer des thèmes YouCan ou Shopify lents. Voici pourquoi mes clients constatent une augmentation moyenne de <span className="text-white font-bold">+18% de leur taux de conversion</span>.
          </p>
        </div>

        {/* Grid points */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-left">
          {points.map((point, index) => (
            <div
              key={index}
              className="bg-zinc-900/60 border border-zinc-900 p-6 sm:p-8 rounded-2xl hover:bg-zinc-900/80 hover:border-zinc-800 transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-center mb-6">
                {point.icon}
              </div>
              <h3 className="text-lg font-extrabold text-white mb-3">
                {point.title}
              </h3>
              <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed">
                {point.description}
              </p>
            </div>
          ))}
        </div>

        {/* Fun callout stat */}
        <div className="mt-16 bg-red-600 text-white p-8 rounded-2xl text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl shadow-red-600/10">
          <div className="space-y-2">
            <h4 className="text-xl sm:text-2xl font-black">
              Bénéficiez d'un Audit Gratuit de votre site actuel !
            </h4>
            <p className="text-white/85 text-xs sm:text-sm max-w-2xl leading-relaxed">
              Vous avez déjà un store Shopify, YouCan ou un site WordPress mais vous ne vendez pas assez ? Envoyez-moi le lien, je l'analyserai gratuitement et vous donnerai 3 conseils pour booster son taux de conversion.
            </p>
          </div>
          <a
            href="https://wa.me/212620490769?text=Bonjour%20Amine%2C%20je%20souhaite%20profiter%20de%20l%27audit%20gratuit%20de%20mon%20site%20web%20actuel."
            target="_blank"
            rel="noopener noreferrer"
            className="w-full md:w-auto text-center shrink-0 bg-white hover:bg-zinc-950 hover:text-white text-black font-extrabold px-6 py-3.5 rounded-xl text-xs sm:text-sm uppercase tracking-wider transition-all"
          >
            Demander mon Audit Gratuit
          </a>
        </div>

      </div>
    </section>
  );
}
