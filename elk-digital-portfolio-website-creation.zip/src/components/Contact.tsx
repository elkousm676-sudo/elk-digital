import React, { useState } from "react";
import { Phone, Mail, MessageSquare, Send, CheckCircle2, ShieldAlert } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    projectType: "landing-page",
    message: ""
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;
    
    // Simulate API Submission
    setSubmitted(true);
  };

  const handleReset = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      projectType: "landing-page",
      message: ""
    });
    setSubmitted(false);
  };

  return (
    <section id="contact" className="py-24 bg-zinc-950 border-b border-zinc-900 relative">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[400px] bg-red-600/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-left">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-block bg-red-600/10 border border-red-500/20 text-red-400 font-mono font-bold text-xs uppercase px-3.5 py-1 rounded-full">
            Contact Direct & Lancement
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Prêt À Lancer <span className="text-red-500">Votre Machine À Vendre</span> ?
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base">
            Que ce soit pour une simple question, un devis personnalisé ou pour lancer votre projet immédiatement, envoyez-moi un message. Je réponds généralement en moins de 30 minutes.
          </p>
        </div>

        {/* Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column - Contact Details & Socials */}
          <div className="lg:col-span-5 space-y-8 flex flex-col justify-between">
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white tracking-tight">
                Coordonnées de <span className="text-red-500">Amine El Kouss</span>
              </h3>
              <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed">
                N'hésitez pas à utiliser l'un des canaux directs pour une prise de contact instantanée. Je suis joignable par appel téléphonique classique ou messagerie WhatsApp.
              </p>

              <div className="space-y-4 pt-4">
                
                {/* Telephone */}
                <a
                  href="tel:0620490769"
                  className="flex items-center space-x-4 p-4 rounded-xl bg-zinc-900/60 border border-zinc-900 hover:border-zinc-800 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-red-600/10 border border-red-500/20 flex items-center justify-center text-red-500 group-hover:bg-red-600 group-hover:text-white transition-all shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 block uppercase font-bold tracking-wider">Téléphone / Mobile</span>
                    <span className="text-white font-extrabold text-sm sm:text-base font-mono">0620490769</span>
                  </div>
                </a>

                {/* Email */}
                <a
                  href="mailto:elkousm676@gmail.com"
                  className="flex items-center space-x-4 p-4 rounded-xl bg-zinc-900/60 border border-zinc-900 hover:border-zinc-800 transition-all group"
                >
                  <div className="w-10 h-10 rounded-lg bg-red-600/10 border border-red-500/20 flex items-center justify-center text-red-500 group-hover:bg-red-600 group-hover:text-white transition-all shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-500 block uppercase font-bold tracking-wider">E-mail Professionnel</span>
                    <span className="text-white font-extrabold text-sm sm:text-base font-mono">elkousm676@gmail.com</span>
                  </div>
                </a>

                {/* WhatsApp status */}
                <div className="flex items-center space-x-3 text-xs bg-red-600/5 border border-red-500/20 p-4 rounded-xl">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                  </span>
                  <p className="text-zinc-300 font-medium leading-relaxed">
                    <strong className="text-white">Dima Online sur WhatsApp :</strong> Envoyez un message ou audio en Darija ou Français pour m'expliquer votre projet.
                  </p>
                </div>

              </div>
            </div>

            {/* Social Media Links */}
            <div className="space-y-4 pt-6 border-t border-zinc-900">
              <h4 className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Retrouvez-moi sur les réseaux</h4>
              <div className="flex flex-wrap gap-3">
                
                {/* Facebook */}
                <a
                  href="https://web.facebook.com/profile.php?id=100006270765868"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800 text-zinc-300 hover:text-white px-4 py-2.5 rounded-lg text-xs font-semibold transition-all"
                >
                  <svg className="w-4 h-4 text-blue-500 fill-blue-500/20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
                  <span>Facebook</span>
                </a>

                {/* Instagram */}
                <a
                  href="https://www.instagram.com/amine_elkous/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800 text-zinc-300 hover:text-white px-4 py-2.5 rounded-lg text-xs font-semibold transition-all"
                >
                  <svg className="w-4 h-4 text-pink-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
                  <span>Instagram</span>
                </a>

                {/* LinkedIn */}
                <a
                  href="https://www.linkedin.com/in/amine-el-kouss-a05421355/?locale=fr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center space-x-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800 text-zinc-300 hover:text-white px-4 py-2.5 rounded-lg text-xs font-semibold transition-all"
                >
                  <svg className="w-4 h-4 text-blue-400 fill-blue-400/20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
                  <span>LinkedIn</span>
                </a>

              </div>
            </div>
          </div>

          {/* Right Column - Interactive Form */}
          <div className="lg:col-span-7 bg-zinc-900/60 border border-zinc-900 p-6 sm:p-8 rounded-2xl relative">
            {!submitted ? (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-1">
                  <h3 className="text-xl font-bold text-white">Formulaire de contact rapide</h3>
                  <p className="text-zinc-400 text-xs">Remplissez ces champs pour réserver votre créneau de devis.</p>
                </div>

                <div className="space-y-4">
                  
                  {/* Name */}
                  <div>
                    <label className="text-xs font-bold text-zinc-400 block mb-1.5 uppercase">Nom Complet *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Ex: Mohamed Alami"
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Phone */}
                    <div>
                      <label className="text-xs font-bold text-zinc-400 block mb-1.5 uppercase">N° de Téléphone *</label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="Ex: 0620490769"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                      />
                    </div>
                    {/* Email */}
                    <div>
                      <label className="text-xs font-bold text-zinc-400 block mb-1.5 uppercase">Adresse E-mail</label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="Ex: mail@gmail.com"
                        className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                      />
                    </div>
                  </div>

                  {/* Project Type */}
                  <div>
                    <label className="text-xs font-bold text-zinc-400 block mb-1.5 uppercase">Type de Projet</label>
                    <select
                      value={formData.projectType}
                      onChange={(e) => setFormData({ ...formData, projectType: e.target.value })}
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500 transition-colors"
                    >
                      <option value="landing-page">Landing Page Monoproduit (YouCan / Shopify / Custom)</option>
                      <option value="youcan-store">Boutique YouCan Complète</option>
                      <option value="shopify-store">Boutique Shopify VIP</option>
                      <option value="wordpress">Site Showcase WordPress</option>
                      <option value="custom-dev">Développement HTML/CSS/JS Sur-Mesure</option>
                      <option value="tracking">Audit de Pixels / API de conversion</option>
                    </select>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="text-xs font-bold text-zinc-400 block mb-1.5 uppercase">Parlez-moi de votre projet</label>
                    <textarea
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Décrivez votre produit, votre niche et vos objectifs de vente..."
                      className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-red-500 transition-colors resize-none"
                    />
                  </div>

                </div>

                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                  <p className="text-[10px] text-zinc-500 italic flex items-center gap-1">
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                    Pas de spam. Vos données restent strictement confidentielles.
                  </p>
                  
                  <button
                    type="submit"
                    className="w-full sm:w-auto bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs px-6 py-3.5 rounded-xl uppercase tracking-wider transition-all flex items-center justify-center space-x-2 cursor-pointer shadow-lg shadow-red-600/20"
                  >
                    <span>Lancer la demande</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>

              </form>
            ) : (
              /* Success state with WhatsApp click as secondary trigger */
              <div className="py-12 text-center space-y-6 animate-fadeIn">
                <div className="w-16 h-16 rounded-full bg-green-500/10 border border-green-500 flex items-center justify-center text-green-500 text-3xl mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>

                <div className="space-y-2 max-w-md mx-auto">
                  <h3 className="text-2xl font-black text-white">Demande Reçue avec Succès !</h3>
                  <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed">
                    Merci <strong className="text-white">{formData.name}</strong>. Votre demande de projet concernant la formule <strong className="text-red-400">{formData.projectType.toUpperCase()}</strong> a bien été enregistrée.
                  </p>
                  <p className="text-zinc-500 text-xs">
                    Je vais examiner vos informations et vous appeler ou vous envoyer un message sur <strong className="text-zinc-300 font-mono">{formData.phone}</strong> sous peu.
                  </p>
                </div>

                <div className="pt-6 border-t border-zinc-900/60 space-y-3 max-w-sm mx-auto">
                  <p className="text-zinc-500 text-[11px]">
                    Vous ne voulez pas attendre ? Accélérez le processus :
                  </p>
                  <a
                    href={`https://wa.me/212620490769?text=Bonjour%20Amine%20(ELK-DIGITAL)%2C%20je%20viens%20de%20remplir%20le%20formulaire%20de%20contact%20pour%20un%20projet%20de%20type%20${encodeURIComponent(formData.projectType)}.`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-extrabold text-xs py-3 rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer uppercase tracking-wider"
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Me contacter sur WhatsApp</span>
                  </a>

                  <button
                    onClick={handleReset}
                    className="text-xs text-zinc-500 hover:text-white transition-colors underline bg-transparent"
                  >
                    Remplir un nouveau formulaire
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
