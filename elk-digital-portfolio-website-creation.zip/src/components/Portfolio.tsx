import { useState } from "react";
import { Laptop, Smartphone, Eye, Sparkles, AlertCircle, ShoppingCart, Check, X, ShieldCheck, RefreshCw } from "lucide-react";

interface Project {
  id: string;
  title: string;
  category: "youcan" | "shopify" | "wordpress" | "custom";
  categoryLabel: string;
  imageColor: string;
  conversion: string;
  speedScore: number;
  highlight: string;
  description: string;
  features: string[];
  // Simulator configuration
  simTitle: string;
  simPrice: string;
  simOldPrice: string;
  simTagline: string;
  simDetails: string[];
  simHeroEmoji: string;
}

export default function Portfolio() {
  const [activeTab, setActiveTab] = useState<string>("all");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [simulatorView, setSimulatorView] = useState<"desktop" | "mobile">("mobile");
  
  // Simulator Interactive States
  const [simName, setSimName] = useState("");
  const [simPhone, setSimPhone] = useState("");
  const [simCity, setSimCity] = useState("Casablanca");
  const [simFormSubmitted, setSimFormSubmitted] = useState(false);
  const [simCartCount, setSimCartCount] = useState(0);

  const projects: Project[] = [
    {
      id: "pureglow",
      title: "PureGlow Cosmetics - Landing Page",
      category: "custom",
      categoryLabel: "HTML/CSS/JS Sur-Mesure",
      imageColor: "from-pink-900 via-rose-950 to-zinc-950",
      conversion: "6.8%",
      speedScore: 99,
      highlight: "Temps de chargement < 0.8s, Idéal Ads Facebook/TikTok",
      description: "Une landing page de cosmétiques haut de gamme développée de zéro sans aucun framework lourd. Le client a multiplié son taux de conversion par 3 après migration depuis un constructeur basique.",
      features: [
        "Score de performance Google PageSpeed : 99/100",
        "Formulaire de commande express directement lié à Google Sheets",
        "Section de témoignages interactifs avec photos",
        "Effet zoom fluide sur les ingrédients du produit"
      ],
      simTitle: "Huile de Figue de Barbarie Bio - PureGlow",
      simPrice: "249 DH",
      simOldPrice: "499 DH",
      simTagline: "L'élixir de jeunesse 100% naturel pressé à froid au Maroc",
      simDetails: [
        "Réduit visiblement les rides et ridules",
        "Hydrate en profondeur sans laisser de film gras",
        "Riche en vitamine E antioxydante"
      ],
      simHeroEmoji: "🧴"
    },
    {
      id: "alfaomega",
      title: "Alfa-Omega Saffron - Shopify Store",
      category: "shopify",
      categoryLabel: "Shopify VIP",
      imageColor: "from-amber-900 via-yellow-950 to-zinc-950",
      conversion: "4.5%",
      speedScore: 92,
      highlight: "Thème customisé, Panier tiroir intelligent, Upsells",
      description: "Boutique Shopify pour une marque d'épices de luxe ciblant le marché européen et du Golfe. Structure optimisée pour l'achat impulsif et la mise en valeur de la qualité biologique.",
      features: [
        "Panier latéral ajaxifié avec indicateur de livraison gratuite",
        "Optimisation SEO sémantique multi-langues",
        "Avis certifiés avec photos importées",
        "Upsell en un clic sur la page de paiement"
      ],
      simTitle: "Safran Pur de Taliouine (Premium Grade A)",
      simPrice: "190 DH",
      simOldPrice: "350 DH",
      simTagline: "Le véritable or rouge marocain, récolté à la main",
      simDetails: [
        "Certifié 100% biologique de la région de Taliouine",
        "Arôme intense et pouvoir colorant exceptionnel",
        "Pot en verre hermétique de protection UV"
      ],
      simHeroEmoji: "🌸"
    },
    {
      id: "smartkitchen",
      title: "SmartKitchen - YouCan Store",
      category: "youcan",
      categoryLabel: "YouCan Store",
      imageColor: "from-red-950 via-zinc-900 to-zinc-950",
      conversion: "5.2%",
      speedScore: 94,
      highlight: "Checkout optimisé pour le COD au Maroc",
      description: "Boutique YouCan dédiée aux ustensiles de cuisine high-tech. Le formulaire d'achat rapide natif YouCan a été stylisé en CSS personnalisé pour éliminer les distractions et rassurer le client.",
      features: [
        "Formulaire COD simplifié avec sélecteur de villes du Maroc",
        "Fiches produits rédigées avec copywriting hypnotique",
        "Bandeaux d'urgence de stock personnalisés",
        "Pixels TikTok et Snapchat configurés via API de conversion"
      ],
      simTitle: "Hachoir Électrique Multifonction Pro",
      simPrice: "299 DH",
      simOldPrice: "599 DH",
      simTagline: "Hachez viande, légumes et herbes en moins de 5 secondes !",
      simDetails: [
        "Moteur surpuissant de 500W à double isolation",
        "4 lames en acier inoxydable chirurgical",
        "Bol en verre trempé haute résistance de 2 Litres"
      ],
      simHeroEmoji: "🔪"
    },
    {
      id: "marrakechriad",
      title: "Riad Marrakech Prestige - WordPress",
      category: "wordpress",
      categoryLabel: "WordPress Showcase",
      imageColor: "from-emerald-950 via-teal-950 to-zinc-950",
      conversion: "Taux d'appel +40%",
      speedScore: 90,
      highlight: "Showcase de luxe, Système de réservation, Multilingue",
      description: "Site WordPress haut de gamme pour une agence de location de Riads privatifs à Marrakech. Intègre une galerie haute définition fluide et un formulaire de contact avancé pour qualifier les leads de luxe.",
      features: [
        "Conception sur-mesure Elementor Pro rapide",
        "Traduction complète Français / Anglais",
        "Formulaire de devis avec sélecteur de dates interactif",
        "Cartes interactives de localisation sans ralentir le site"
      ],
      simTitle: "Riad Signature - Privatisation Médina",
      simPrice: "4500 DH / nuit",
      simOldPrice: "6000 DH",
      simTagline: "Une oasis de sérénité absolue au cœur de Marrakech",
      simDetails: [
        "5 suites de luxe avec salles de bain privatives",
        "Piscine intérieure chauffée et rooftop panoramique",
        "Personnel de maison de classe internationale inclus"
      ],
      simHeroEmoji: "🕌"
    },
    {
      id: "apexfit",
      title: "ApexFit - High Conversion Landing Page",
      category: "youcan",
      categoryLabel: "YouCan Landing Page",
      imageColor: "from-blue-950 via-slate-900 to-zinc-950",
      conversion: "7.1%",
      speedScore: 95,
      highlight: "Page monoproduit ultra responsive, Checkout express",
      description: "Une page de vente axée sport & fitness construite directement sur YouCan à l'aide de custom HTML/CSS injecté. Idéale pour les campagnes Google Ads et Meta Ads à fort trafic.",
      features: [
        "Vitesse de chargement optimisée pour la 4G marocaine",
        "Tableau comparatif des prix pour encourager l'achat par pack",
        "Section FAQ rétractable pour dissiper les doutes",
        "Sticky 'Acheter maintenant' persistant sur mobile"
      ],
      simTitle: "Ceinture de Sudation Néoprène Pro-Fit",
      simPrice: "199 DH",
      simOldPrice: "399 DH",
      simTagline: "Brûlez plus de graisses abdominales durant vos séances",
      simDetails: [
        "Néoprène Premium thermo-actif sans latex",
        "Soutien lombaire intégré pour préserver le dos",
        "Taille unique ajustable et invisible sous les vêtements"
      ],
      simHeroEmoji: "🏋️"
    },
    {
      id: "saficlay",
      title: "Safi Pottery - International Showcase",
      category: "custom",
      categoryLabel: "HTML/CSS/JS Sur-Mesure",
      imageColor: "from-orange-950 via-amber-950 to-zinc-950",
      conversion: "Prise de contact +25%",
      speedScore: 98,
      highlight: "Design artistique, Portfolio filtrable en JS",
      description: "Site internet pour un artisan potier de Safi exportant vers les USA et l'Europe. Un design terre-cuite et noir ultra moderne qui donne une image extrêmement luxueuse et rassure les importateurs.",
      features: [
        "Zéro CMS : développé entièrement à la main",
        "Galerie photo interactive avec zoom fluide haute résolution",
        "Hébergement gratuit à vie sur Cloudflare Pages",
        "Formulaire de demande de catalogue sécurisé anti-spam"
      ],
      simTitle: "Vase Royal en Céramique Émaillée Noire",
      simPrice: "850 DH",
      simOldPrice: "1400 DH",
      simTagline: "Pièce unique façonnée à la main par nos maîtres artisans à Safi",
      simDetails: [
        "Terre cuite locale de haute qualité, émaillage secret",
        "Hauteur: 45cm - Idéal pour décoration de prestige",
        "Certificat d'authenticité signé fourni"
      ],
      simHeroEmoji: "🏺"
    }
  ];

  const filteredProjects = activeTab === "all" 
    ? projects 
    : projects.filter(p => p.category === activeTab);

  const openSimulator = (project: Project) => {
    setSelectedProject(project);
    setSimName("");
    setSimPhone("");
    setSimFormSubmitted(false);
    setSimCartCount(0);
  };

  const closeSimulator = () => {
    setSelectedProject(null);
  };

  const handleSimSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!simName || !simPhone) return;
    setSimFormSubmitted(true);
    setSimCartCount(1);
  };

  return (
    <section id="portfolio" className="bg-zinc-950 py-24 border-b border-zinc-900 relative">
      <div className="absolute bottom-0 right-0 w-72 h-72 bg-red-600/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-4 max-w-2xl text-left">
            <div className="inline-block bg-red-600/10 border border-red-500/20 text-red-400 font-mono font-bold text-xs uppercase px-3.5 py-1 rounded-full">
              Démonstration de Force
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Mes Réalisations : <span className="text-red-500">Du Code & Des Ventes</span>
            </h2>
            <p className="text-zinc-400 text-sm sm:text-base">
              Découvrez des projets réels optimisés. Ne me croyez pas sur parole : <span className="text-white font-semibold">testez directement les démos interactives intégrées</span> ci-dessous pour ressentir la vitesse et l'expérience utilisateur !
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-1.5 bg-zinc-900/60 p-1.5 rounded-xl border border-zinc-800 self-start">
            {[
              { id: "all", label: "Tous les projets" },
              { id: "youcan", label: "YouCan" },
              { id: "shopify", label: "Shopify" },
              { id: "wordpress", label: "WordPress" },
              { id: "custom", label: "Custom HTML/CSS" }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? "bg-red-600 text-white shadow-md shadow-red-600/15"
                    : "text-zinc-400 hover:text-white hover:bg-zinc-800/50"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col justify-between group hover:border-zinc-700/80 transition-all duration-300"
            >
              <div>
                {/* Visual Header */}
                <div className={`h-48 bg-gradient-to-br ${project.imageColor} relative p-6 flex flex-col justify-between overflow-hidden border-b border-zinc-900`}>
                  {/* Grid effect inside card header */}
                  <div className="absolute inset-0 bg-[linear-gradient(to_right,#3f3f46_1px,transparent_1px),linear-gradient(to_bottom,#3f3f46_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-10" />
                  
                  {/* Category Pill */}
                  <span className="self-start bg-black/60 backdrop-blur-md text-white border border-zinc-700/50 px-2.5 py-1 rounded text-[10px] font-mono uppercase tracking-wider relative z-10">
                    {project.categoryLabel}
                  </span>

                  {/* Icon Representation */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-5xl opacity-40 group-hover:scale-110 transition-transform duration-300">
                    {project.simHeroEmoji}
                  </div>

                  {/* Metrics Overlay */}
                  <div className="flex justify-between items-center relative z-10 pt-16">
                    <div className="bg-black/75 backdrop-blur-md px-2.5 py-1.5 rounded border border-green-500/20 text-xs">
                      <span className="text-zinc-400 text-[9px] block uppercase font-semibold">Taux Conversion</span>
                      <span className="text-green-400 font-black tracking-wide">{project.conversion}</span>
                    </div>

                    <div className="bg-black/75 backdrop-blur-md px-2.5 py-1.5 rounded border border-red-500/20 text-xs text-right">
                      <span className="text-zinc-400 text-[9px] block uppercase font-semibold">Google Speed</span>
                      <span className="text-red-500 font-black tracking-wide">{project.speedScore}/100</span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="p-6 space-y-4">
                  <div className="space-y-1">
                    <h3 className="text-lg font-bold text-white group-hover:text-red-500 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-red-400/90 text-xs font-semibold font-mono flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-red-500" />
                      {project.highlight}
                    </p>
                  </div>

                  <p className="text-zinc-400 text-xs leading-relaxed">
                    {project.description}
                  </p>

                  <div className="space-y-2 pt-2 border-t border-zinc-800/60">
                    {project.features.slice(0, 3).map((feat, index) => (
                      <div key={index} className="flex items-start gap-1.5 text-zinc-300 text-[11px]">
                        <Check className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
                        <span className="truncate">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => openSimulator(project)}
                  className="w-full bg-zinc-950 hover:bg-red-600 hover:text-white border border-zinc-800 hover:border-red-500/30 text-zinc-200 font-extrabold text-xs py-3 rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer uppercase tracking-wider shadow-sm"
                >
                  <Eye className="w-4 h-4" />
                  <span>Tester la démo interactive</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Live Simulator Modal */}
        {selectedProject && (
          <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            
            {/* Modal Box */}
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden relative flex flex-col h-[90vh]">
              
              {/* Modal Topbar */}
              <div className="bg-zinc-900 px-6 py-4 border-b border-zinc-800 flex items-center justify-between shrink-0">
                <div className="flex items-center space-x-3 text-left">
                  <div className="bg-red-600/20 text-red-400 text-[10px] font-mono px-2 py-0.5 rounded border border-red-500/20">
                    SIMULATEUR DE PROJET
                  </div>
                  <h3 className="text-white font-bold text-sm sm:text-base truncate">
                    {selectedProject.title}
                  </h3>
                </div>
                
                <button
                  onClick={closeSimulator}
                  className="text-zinc-400 hover:text-white p-1 rounded-lg hover:bg-zinc-800 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Split Content: Left details, Right Simulated Mobile/Desktop */}
              <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Left Side: Real Technical Specs & Analysis */}
                <div className="lg:col-span-4 space-y-6 text-left">
                  <div className="space-y-2">
                    <h4 className="text-xs uppercase tracking-widest text-zinc-500 font-bold">Rapport Technique</h4>
                    <p className="text-sm text-zinc-300">
                      Voici un aperçu du rendu technique conçu pour ce client. J'optimise le parcours utilisateur pour déclencher la commande immédiate.
                    </p>
                  </div>

                  {/* Real Stats */}
                  <div className="grid grid-cols-2 gap-3 bg-zinc-900 p-4 rounded-xl border border-zinc-800">
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase font-bold">Conversion</span>
                      <span className="text-green-400 text-lg font-black">{selectedProject.conversion}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block uppercase font-bold">Vitesse Mobile</span>
                      <span className="text-red-500 text-lg font-black">{selectedProject.speedScore}/100</span>
                    </div>
                  </div>

                  {/* Implementation details */}
                  <div className="space-y-3">
                    <h5 className="text-xs font-bold text-white uppercase">Fonctionnalités Clés :</h5>
                    <ul className="space-y-2.5 text-xs text-zinc-400">
                      {selectedProject.features.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <Check className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t border-zinc-900 space-y-3">
                    <p className="text-[10px] text-zinc-500 italic flex items-center gap-1.5">
                      <AlertCircle className="w-3.5 h-3.5 text-zinc-500" />
                      Hébergement gratuit ultra performant inclus.
                    </p>
                    <a
                      href="https://wa.me/212620490769?text=Bonjour%20Amine%2C%20je%20suis%20intéressé%20par%20un%20projet%20du%20type%20de%20%22"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs py-3 rounded-xl transition-all flex items-center justify-center space-x-1 uppercase tracking-wider shadow-lg shadow-red-600/15"
                    >
                      <span>Commander Ce Type de Site</span>
                    </a>
                  </div>
                </div>

                {/* Right Side: Web Browser Simulator Mock */}
                <div className="lg:col-span-8 flex flex-col">
                  
                  {/* Simulator Controls */}
                  <div className="bg-zinc-900 border border-zinc-800 p-3 rounded-t-xl flex items-center justify-between shrink-0">
                    <div className="flex space-x-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                      <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                      <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
                    </div>

                    {/* Viewport Switcher */}
                    <div className="flex bg-zinc-950 rounded-lg p-1 border border-zinc-800/80">
                      <button
                        onClick={() => setSimulatorView("mobile")}
                        className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all flex items-center space-x-1.5 cursor-pointer ${
                          simulatorView === "mobile" 
                            ? "bg-zinc-800 text-white" 
                            : "text-zinc-500 hover:text-zinc-300"
                        }`}
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>Mobile</span>
                      </button>
                      <button
                        onClick={() => setSimulatorView("desktop")}
                        className={`px-3 py-1 text-[10px] font-bold rounded-md transition-all flex items-center space-x-1.5 cursor-pointer ${
                          simulatorView === "desktop" 
                            ? "bg-zinc-800 text-white" 
                            : "text-zinc-500 hover:text-zinc-300"
                        }`}
                      >
                        <Laptop className="w-3.5 h-3.5" />
                        <span>Desktop</span>
                      </button>
                    </div>

                    {/* Reload Button */}
                    <button
                      onClick={() => {
                        setSimFormSubmitted(false);
                        setSimName("");
                        setSimPhone("");
                        setSimCartCount(0);
                      }}
                      className="text-zinc-500 hover:text-white p-1 rounded transition-colors"
                      title="Réinitialiser la Démo"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Browser content window container */}
                  <div className="bg-zinc-900/40 border-l border-r border-b border-zinc-800 rounded-b-xl flex justify-center items-start p-4 bg-zinc-950 flex-1 overflow-y-auto min-h-[350px]">
                    
                    {/* Responsive Container Wrapper */}
                    <div className={`transition-all duration-300 bg-black border border-zinc-800/80 rounded-xl shadow-2xl text-zinc-300 text-xs overflow-hidden ${
                      simulatorView === "mobile" ? "w-[320px] min-h-[500px]" : "w-full max-w-[550px] min-h-[500px]"
                    }`}>
                      
                      {/* Interactive App Screen Header */}
                      <div className="bg-zinc-900 px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                        <div className="font-extrabold text-white text-[10px] tracking-wide flex items-center gap-1 uppercase">
                          <span className="text-red-500">★</span> BrandStore
                        </div>
                        <div className="relative">
                          <ShoppingCart className="w-4 h-4 text-zinc-400" />
                          {simCartCount > 0 && (
                            <span className="absolute -top-1.5 -right-2 bg-red-600 text-white font-extrabold text-[8px] px-1.5 py-0.2 rounded-full animate-bounce">
                              {simCartCount}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Simulator Body */}
                      <div className="p-4 space-y-4 text-left">
                        
                        {/* Interactive Countdown */}
                        <div className="bg-red-600 text-white text-center py-1.5 px-3 rounded font-bold text-[10px] animate-pulse flex items-center justify-between">
                          <span>🔥 STOCK TRÈS LIMITÉ !</span>
                          <span className="font-mono">13 : 42 : 09</span>
                        </div>

                        {/* Product Detail Card */}
                        <div className="space-y-2">
                          <div className="w-full h-28 bg-zinc-900 rounded-lg border border-zinc-800 flex items-center justify-center text-4xl relative">
                            {selectedProject.simHeroEmoji}
                            <span className="absolute top-2 right-2 bg-red-600 text-white text-[8px] font-bold uppercase px-1.5 py-0.5 rounded">
                              Livraison Gratuite
                            </span>
                          </div>

                          <div className="flex justify-between items-start pt-1">
                            <div>
                              <h5 className="font-extrabold text-white text-sm">{selectedProject.simTitle}</h5>
                              <p className="text-[10px] text-zinc-400">{selectedProject.simTagline}</p>
                            </div>
                            <div className="text-right shrink-0">
                              <div className="text-red-500 font-black text-sm">{selectedProject.simPrice}</div>
                              <div className="text-zinc-500 line-through text-[10px]">{selectedProject.simOldPrice}</div>
                            </div>
                          </div>
                        </div>

                        {/* Product Highlights */}
                        <div className="bg-zinc-900/60 border border-zinc-800 p-3 rounded-lg space-y-1.5">
                          {selectedProject.simDetails.map((det, index) => (
                            <div key={index} className="flex items-start gap-1.5 text-[10px]">
                              <Check className="w-3.5 h-3.5 text-green-500 shrink-0" />
                              <span>{det}</span>
                            </div>
                          ))}
                        </div>

                        {/* Form state handling */}
                        {!simFormSubmitted ? (
                          <form onSubmit={handleSimSubmit} className="bg-zinc-900 p-3 rounded-xl border border-zinc-800 space-y-3">
                            <h6 className="font-extrabold text-white text-[11px] uppercase tracking-wide flex items-center gap-1 border-b border-zinc-800 pb-1.5">
                              <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
                              Saisissez vos informations :
                            </h6>
                            
                            <div className="space-y-2">
                              <div>
                                <label className="text-[9px] text-zinc-400 block mb-0.5">Nom & Prénom *</label>
                                <input
                                  type="text"
                                  required
                                  value={simName}
                                  onChange={(e) => setSimName(e.target.value)}
                                  placeholder="Ex: Amine El Alami"
                                  className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-red-500 transition-colors"
                                />
                              </div>

                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                <div>
                                  <label className="text-[9px] text-zinc-400 block mb-0.5">Téléphone *</label>
                                  <input
                                    type="tel"
                                    required
                                    value={simPhone}
                                    onChange={(e) => setSimPhone(e.target.value)}
                                    placeholder="Ex: 0612345678"
                                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-red-500 transition-colors"
                                  />
                                </div>
                                <div>
                                  <label className="text-[9px] text-zinc-400 block mb-0.5">Ville *</label>
                                  <select
                                    value={simCity}
                                    onChange={(e) => setSimCity(e.target.value)}
                                    className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1.5 text-xs text-white focus:outline-none focus:border-red-500 transition-colors"
                                  >
                                    <option value="Casablanca">Casablanca</option>
                                    <option value="Rabat">Rabat</option>
                                    <option value="Marrakech">Marrakech</option>
                                    <option value="Tanger">Tanger</option>
                                    <option value="Fes">Fes</option>
                                    <option value="Agadir">Agadir</option>
                                    <option value="Oujda">Oujda</option>
                                  </select>
                                </div>
                              </div>
                            </div>

                            <button
                              type="submit"
                              className="w-full bg-green-600 hover:bg-green-700 text-white font-extrabold py-2.5 rounded-lg uppercase text-[10px] tracking-widest transition-all flex items-center justify-center space-x-1 cursor-pointer"
                            >
                              <span>Acheter Maintenant</span>
                            </button>
                            <p className="text-[9px] text-center text-zinc-500">
                              🤝 Paiement en espèces lors de la livraison.
                            </p>
                          </form>
                        ) : (
                          /* Thank You Success Simulator */
                          <div className="bg-zinc-900/80 p-6 rounded-xl border border-green-500/30 text-center space-y-4 animate-fadeIn">
                            <div className="w-12 h-12 rounded-full bg-green-500/10 border border-green-500 flex items-center justify-center text-green-500 mx-auto text-xl">
                              ✓
                            </div>
                            
                            <div className="space-y-1">
                              <h6 className="font-extrabold text-white text-base">Commande Validée !</h6>
                              <p className="text-[10px] text-zinc-400">
                                Merci <strong className="text-white">{simName}</strong> de {simCity}. Votre commande de <strong className="text-white">{selectedProject.simTitle}</strong> a bien été enregistrée.
                              </p>
                            </div>

                            {/* Pixel firing representation */}
                            <div className="bg-black border border-green-500/20 p-2.5 rounded text-[8px] font-mono text-left space-y-1">
                              <div className="text-green-400 font-bold flex items-center gap-1.5">
                                <ShieldCheck className="w-3.5 h-3.5" />
                                <span>PIXEL TRACKING SYSTEM (API) :</span>
                              </div>
                              <p className="text-zinc-500">Event name: <span className="text-white">Purchase</span></p>
                              <p className="text-zinc-500">Value: <span className="text-white">{selectedProject.simPrice}</span></p>
                              <p className="text-zinc-500">Phone Status: <span className="text-green-500">Normalized & Verified</span></p>
                              <p className="text-zinc-400">Status: Sent to Shopify/YouCan Webhook without delays.</p>
                            </div>

                            <button
                              onClick={() => {
                                setSimFormSubmitted(false);
                                setSimName("");
                                setSimPhone("");
                                setSimCartCount(0);
                              }}
                              className="text-xs text-red-500 hover:underline font-bold"
                            >
                              Faire un autre test de commande
                            </button>
                          </div>
                        )}

                        {/* Secure footer badge */}
                        <div className="text-center text-[9px] text-zinc-500">
                          🛡️ SSL Encrypted Checkout | Powered by ELK-DIGITAL
                        </div>

                      </div>
                    </div>

                  </div>

                </div>

              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
}
