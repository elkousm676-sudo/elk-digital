import { Layout, ShoppingBag, Globe2, Code, Activity, Zap, Check } from "lucide-react";

export default function Services() {
  const services = [
    {
      icon: <Layout className="w-6 h-6 text-red-500" />,
      title: "Landing Pages High-Conversion",
      description: "Des pages de vente monoproduit taillées pour convertir immédiatement vos visiteurs en acheteurs. Idéal pour le Cash On Delivery (COD).",
      features: [
        "Temps de chargement ultra-rapide (< 1.2s)",
        "Formulaire d'achat express en 1 clic",
        "Design mobile-first responsive à 100%",
        "Avis clients et triggers de rareté"
      ],
      tag: "Populaire"
    },
    {
      icon: <ShoppingBag className="w-6 h-6 text-red-500" />,
      title: "Stores YouCan & Shopify Optimisés",
      description: "Création et personnalisation de boutiques e-commerce complètes. Fini les thèmes basiques, obtenez un store premium digne des plus grandes marques.",
      features: [
        "Personnalisation en code CSS/JS personnalisé",
        "Intégration d'applications d'upsell",
        "Fiches produits structurées de A à Z",
        "Configuration complète des frais de livraison"
      ],
      tag: "Indispensable"
    },
    {
      icon: <Globe2 className="w-6 h-6 text-red-500" />,
      title: "Sites Web WordPress de Pro",
      description: "Sites vitrines ou e-commerce dynamiques sous WordPress. Parfait pour les entreprises, agences immobilières, consultants ou services locaux.",
      features: [
        "Design sur-mesure avec Elementor Pro",
        "Panneau d'administration facile à utiliser",
        "Sécurisé contre les attaques et hacks",
        "Optimisation SEO pour Google Maroc & International"
      ],
      tag: "Sur-Mesure"
    },
    {
      icon: <Code className="w-6 h-6 text-red-500" />,
      title: "Développement HTML / CSS / JS",
      description: "Vous voulez un code propre, sans plugin lourd ? Je développe votre site de A à Z en pur code natif pour une performance et une sécurité absolues.",
      features: [
        "Zéro dépendance, code propre et optimisé",
        "Parfait pour être hébergé sur GitHub ou Cloudflare",
        "Animations fluides et modernes",
        "Maintenance ultra simple"
      ],
      tag: "Haute Performance"
    },
    {
      icon: <Activity className="w-6 h-6 text-red-500" />,
      title: "Tracking Pixels & Conversions API",
      description: "Un pixel mal configuré détruit vos campagnes publicitaires. J'intègre correctement vos pixels et serveurs API pour un ciblage parfait.",
      features: [
        "Pixel Facebook & Conversion API (CAPI)",
        "TikTok Pixel avec événements avancés",
        "Snapchat Pixel & Google Analytics 4",
        "Suivi précis sans perte de données sur iOS 14+"
      ],
      tag: "Recommandé"
    },
    {
      icon: <Zap className="w-6 h-6 text-red-500" />,
      title: "Refonte & Optimisation de Vitesse",
      description: "Votre site actuel est trop lent et vous perdez des clients ? Je nettoie le code, compresse les visuels et booste la vitesse globale.",
      features: [
        "Score Google PageSpeed supérieur à 90+",
        "Compression d'images de dernière génération",
        "Suppression des scripts inutiles et lourds",
        "Meilleur classement SEO naturel"
      ],
      tag: "Vitesse Boostée"
    }
  ];

  return (
    <section id="services" className="bg-zinc-900/50 py-24 border-t border-b border-zinc-900 relative">
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-64 h-64 bg-red-600/5 rounded-full blur-[100px] pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-block bg-red-600/10 border border-red-500/20 text-red-400 font-mono font-bold text-xs uppercase px-3.5 py-1 rounded-full">
            Ce Que Je Fais De Mieux
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Des Services Web Conçus Pour <span className="text-red-500 font-black">Maximiser Votre Chiffre d'Affaires</span>
          </h2>
          <p className="text-zinc-400 text-base sm:text-lg">
            Que vous vendiez en e-commerce (COD), proposiez des services ou souhaitiez simplement asseoir votre image de marque au Maroc, j'ai la solution technique adaptée à vos besoins.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-6 sm:p-8 hover:border-red-500/50 transition-all duration-300 group hover:-translate-y-1.5 flex flex-col justify-between"
            >
              <div>
                {/* Icon & Tag */}
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center group-hover:bg-red-600/10 group-hover:border-red-500/30 transition-all">
                    {service.icon}
                  </div>
                  <span className="text-[10px] font-mono font-semibold text-zinc-400 bg-zinc-900 border border-zinc-800 px-2.5 py-1 rounded">
                    {service.tag}
                  </span>
                </div>

                {/* Title & Description */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-red-400 transition-colors">
                  {service.title}
                </h3>
                <p className="text-zinc-400 text-sm leading-relaxed mb-6">
                  {service.description}
                </p>
              </div>

              {/* Features List */}
              <div className="border-t border-zinc-900 pt-6 space-y-3">
                {service.features.map((feature, fIndex) => (
                  <div key={fIndex} className="flex items-start space-x-2.5">
                    <Check className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                    <span className="text-zinc-300 text-xs font-medium">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Conversion Trigger */}
        <div className="mt-16 bg-gradient-to-r from-zinc-950 via-zinc-900 to-zinc-950 border border-zinc-800 p-6 sm:p-10 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center sm:text-left">
            <h4 className="text-lg sm:text-xl font-bold text-white">
              Vous avez un projet e-commerce spécifique en tête ?
            </h4>
            <p className="text-zinc-400 text-xs sm:text-sm">
              Parlons-en dès aujourd'hui. Je peux vous conseiller gratuitement sur le meilleur choix technique.
            </p>
          </div>
          <a
            href="https://wa.me/212620490769?text=Bonjour%20Amine%2C%20je%20souhaite%20un%20conseil%20gratuit%20pour%20mon%20projet%20e-commerce."
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto bg-white text-black font-extrabold px-6 py-3.5 rounded-xl transition-all text-sm text-center tracking-wide uppercase hover:bg-red-600 hover:text-white shrink-0 hover:shadow-lg hover:shadow-red-600/20"
          >
            Conseil Gratuit Via WhatsApp
          </a>
        </div>

      </div>
    </section>
  );
}
