interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const quickLinks = [
    { name: "Accueil", id: "home" },
    { name: "Services", id: "services" },
    { name: "Portfolio & Démos", id: "portfolio" },
    { name: "Simulateur de Devis", id: "estimator" },
    { name: "Pourquoi Nous ?", id: "why-us" },
    { name: "Contact", id: "contact" },
  ];

  return (
    <footer className="bg-black text-zinc-400 py-16 border-t border-zinc-900 relative overflow-hidden">
      
      {/* Background glow */}
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-red-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-left">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-12">
          
          {/* Brand Col */}
          <div className="md:col-span-5 space-y-4">
            <div 
              onClick={() => onNavigate("home")}
              className="flex items-center space-x-2 cursor-pointer group"
            >
              <div className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center text-white font-black text-lg tracking-tighter shadow-md shadow-red-600/20">
                E
              </div>
              <span className="text-lg font-black text-white tracking-wider font-mono">
                ELK<span className="text-red-600 font-extrabold">-</span>DIGITAL
              </span>
            </div>
            
            <p className="text-xs sm:text-sm text-zinc-500 leading-relaxed max-w-sm">
              Spécialiste de la création de sites internet, landing pages e-commerce et boutiques de vente en ligne sur YouCan, Shopify et WordPress. Optimisé pour la performance et le taux de conversion.
            </p>

            {/* Hosting Note requested by user */}
            <div className="p-3 bg-zinc-900/60 border border-zinc-900 rounded-xl max-w-sm space-y-1">
              <span className="text-[9px] font-mono font-bold text-red-500 uppercase tracking-wider block">
                💻 Déploiement Simplifié
              </span>
              <p className="text-[10px] text-zinc-500 leading-normal">
                Ce site est 100% statique et optimisé pour être hébergé gratuitement sur <strong className="text-zinc-300">GitHub Pages</strong> ou <strong className="text-zinc-300">Cloudflare Pages</strong>. Vous n'avez qu'à faire un simple copier-coller du dossier de build !
              </p>
            </div>
          </div>

          {/* Quick Links Col */}
          <div className="md:col-span-3 space-y-4">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">Plan du Site</h4>
            <ul className="space-y-2 text-xs">
              {quickLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => onNavigate(link.id)}
                    className="hover:text-red-500 transition-colors text-zinc-500 hover:underline bg-transparent text-left cursor-pointer"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Col */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider">Contact Amine</h4>
            <ul className="space-y-3 text-xs text-zinc-500">
              <li>
                <span className="text-[10px] text-zinc-600 block uppercase font-semibold">Téléphone</span>
                <a href="tel:0620490769" className="text-zinc-300 font-mono font-bold hover:text-red-500 transition-colors">
                  0620490769
                </a>
              </li>
              <li>
                <span className="text-[10px] text-zinc-600 block uppercase font-semibold">E-mail</span>
                <a href="mailto:elkousm676@gmail.com" className="text-zinc-300 font-mono font-bold hover:text-red-500 transition-colors">
                  elkousm676@gmail.com
                </a>
              </li>
              <li>
                <span className="text-[10px] text-zinc-600 block uppercase font-semibold">Zone d'activité</span>
                <span className="text-zinc-300 font-semibold">
                  Maroc (Casablanca, Rabat, Marrakech, Agadir, etc.) & International à distance.
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Credits */}
        <div className="pt-8 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-600 gap-4">
          <p>© 2026 ELK-DIGITAL. Tous droits réservés.</p>
          <div className="flex items-center space-x-1">
            <span>Conçu avec passion par</span>
            <a
              href="https://web.facebook.com/profile.php?id=100006270765868"
              target="_blank"
              rel="noopener noreferrer"
              className="text-zinc-400 hover:text-red-500 transition-colors font-extrabold"
            >
              Amine El Kouss
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
}
