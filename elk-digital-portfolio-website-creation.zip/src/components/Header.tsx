import { useState, useEffect } from "react";
import { Phone, Mail, Menu, X, MessageSquare } from "lucide-react";

interface HeaderProps {
  onNavigate: (sectionId: string) => void;
}

export default function Header({ onNavigate }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Accueil", id: "home" },
    { name: "Services", id: "services" },
    { name: "Portfolio", id: "portfolio" },
    { name: "Simulateur de Devis", id: "estimator" },
    { name: "Pourquoi Nous ?", id: "why-us" },
    { name: "Contact", id: "contact" },
  ];

  const handleItemClick = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-black/90 backdrop-blur-md border-b border-zinc-800/80 shadow-lg py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div 
            onClick={() => handleItemClick("home")}
            className="flex items-center space-x-2 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-lg bg-red-600 flex items-center justify-center text-white font-black text-xl tracking-tighter shadow-md shadow-red-600/20 group-hover:bg-red-700 transition-colors">
              E
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black text-white tracking-wider font-mono">
                ELK<span className="text-red-600 font-extrabold">-</span>DIGITAL
              </span>
              <span className="text-[9px] text-zinc-400 uppercase tracking-widest font-semibold">
                Web & E-Com Specialist
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className="px-4 py-2 text-sm font-medium text-zinc-300 hover:text-white hover:bg-zinc-900/50 rounded-lg transition-all cursor-pointer"
              >
                {item.name}
              </button>
            ))}
          </nav>

          {/* Quick Contact & Call to Action */}
          <div className="hidden lg:flex items-center space-x-4">
            <a
              href="tel:0620490769"
              className="flex items-center space-x-2 text-zinc-300 hover:text-red-500 transition-colors text-sm"
              title="Appeler Amine"
            >
              <div className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center border border-zinc-800">
                <Phone className="w-3.5 h-3.5 text-red-500" />
              </div>
              <span className="font-semibold text-xs">0620490769</span>
            </a>
            <a
              href="https://wa.me/212620490769?text=Bonjour%20ELK-DIGITAL%2C%20je%20souhaite%20avoir%20plus%20d%27informations%20sur%20vos%20services."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white font-semibold text-xs px-4 py-2.5 rounded-lg transition-all duration-300 shadow-md shadow-red-600/25 uppercase tracking-wide hover:-translate-y-0.5"
            >
              <MessageSquare className="w-3.5 h-3.5 mr-1" />
              Projet Gratuit
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-zinc-400 hover:text-white p-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-600"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden fixed inset-x-0 bg-zinc-950 border-b border-zinc-800 transition-all duration-300 ease-in-out transform ${
          isOpen ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-full pointer-events-none"
        }`}
        style={{ top: "64px" }}
      >
        <div className="px-4 pt-4 pb-6 space-y-2 bg-black">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className="block w-full text-left px-4 py-3 rounded-lg text-base font-semibold text-zinc-300 hover:text-white hover:bg-zinc-900 transition-all border-l-2 border-transparent hover:border-red-600"
            >
              {item.name}
            </button>
          ))}
          <div className="pt-4 border-t border-zinc-800/50 flex flex-col space-y-3 px-4">
            <a
              href="tel:0620490769"
              className="flex items-center space-x-3 text-zinc-300 hover:text-red-500 transition-colors py-1"
            >
              <Phone className="w-4 h-4 text-red-500" />
              <span className="font-semibold text-sm">0620490769</span>
            </a>
            <a
              href="mailto:elkousm676@gmail.com"
              className="flex items-center space-x-3 text-zinc-300 hover:text-red-500 transition-colors py-1"
            >
              <Mail className="w-4 h-4 text-red-500" />
              <span className="font-semibold text-sm">elkousm676@gmail.com</span>
            </a>
            <a
              href="https://wa.me/212620490769?text=Bonjour%20ELK-DIGITAL%2C%20je%20souhaite%20avoir%20plus%20d%27informations."
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center space-x-2 bg-red-600 text-white font-bold py-3 rounded-xl transition-all shadow-md shadow-red-600/30 text-sm"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Contactez-moi sur WhatsApp</span>
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
