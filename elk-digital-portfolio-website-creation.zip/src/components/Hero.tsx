import { ArrowRight, MessageSquare, CheckCircle, Shield, ShoppingCart, Zap, Globe } from "lucide-react";

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section id="home" className="relative bg-zinc-950 text-white pt-28 pb-20 overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[500px] bg-red-600/10 rounded-full blur-[140px] pointer-events-none" />
      
      {/* Grid Pattern overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f1f23_1px,transparent_1px),linear-gradient(to_bottom,#1f1f23_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column - Content */}
          <div className="lg:col-span-7 space-y-8 text-left">
            
            {/* Badge */}
            <div className="inline-flex items-center space-x-2 bg-zinc-900 border border-zinc-800 rounded-full px-4 py-1.5 text-xs text-zinc-300">
              <span className="flex h-2 w-2 rounded-full bg-red-500 animate-pulse" />
              <span className="font-semibold text-zinc-100">Amine El Kouss</span>
              <span className="text-zinc-500">|</span>
              <span className="text-red-400">Expert E-commerce & Web Dev</span>
            </div>

            {/* Big Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] text-white">
              Besoin d'une <span className="text-red-600 underline decoration-red-600/40 underline-offset-4">Landing Page</span> ou <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-red-500">Boutique Pro</span> qui Vend Vraiment ?
            </h1>

            {/* Subtitle */}
            <p className="text-zinc-400 text-lg sm:text-xl font-normal leading-relaxed max-w-2xl">
              Je conçois et développe des <strong className="text-zinc-100">Landing Pages ultra-rapides</strong>, des boutiques e-commerce optimisées sur <strong className="text-red-500">YouCan</strong> et <strong className="text-red-500">Shopify</strong>, ainsi que des sites vitrines sous <strong className="text-zinc-100">WordPress</strong> ou <strong className="text-zinc-100">HTML/CSS/JS</strong>. Boostez vos ventes en COD au Maroc et à l'international.
            </p>

            {/* Platform Badges */}
            <div className="flex flex-wrap gap-2 pt-2">
              <span className="bg-zinc-900/90 border border-zinc-800 text-white font-mono text-xs px-3 py-1.5 rounded-md flex items-center gap-1.5">
                <span className="text-red-500 font-bold">🛒</span> YouCan Store
              </span>
              <span className="bg-zinc-900/90 border border-zinc-800 text-white font-mono text-xs px-3 py-1.5 rounded-md flex items-center gap-1.5">
                <span className="text-green-500 font-bold">🛍️</span> Shopify VIP
              </span>
              <span className="bg-zinc-900/90 border border-zinc-800 text-white font-mono text-xs px-3 py-1.5 rounded-md flex items-center gap-1.5">
                <span className="text-blue-400 font-bold">Ⓜ️</span> WordPress
              </span>
              <span className="bg-zinc-900/90 border border-zinc-800 text-white font-mono text-xs px-3 py-1.5 rounded-md flex items-center gap-1.5">
                <span className="text-red-500 font-bold">&lt;/&gt;</span> Custom HTML/CSS/JS
              </span>
              <span className="bg-zinc-900/90 border border-zinc-800 text-white font-mono text-xs px-3 py-1.5 rounded-md flex items-center gap-1.5">
                <span className="text-amber-500 font-bold">⚡</span> Pixel Tracking & API
              </span>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a
                href="https://wa.me/212620490769?text=Bonjour%20Amine%2C%20je%20viens%20de%20votre%20site%20ELK-DIGITAL%20et%20je%20souhaite%20lancer%20un%20projet."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center space-x-3 bg-red-600 hover:bg-red-700 text-white font-bold px-8 py-4 rounded-xl transition-all shadow-lg shadow-red-600/30 text-base hover:-translate-y-1"
              >
                <MessageSquare className="w-5 h-5 animate-pulse" />
                <span>Discuter sur WhatsApp</span>
              </a>
              <button
                onClick={() => onNavigate("portfolio")}
                className="flex items-center justify-center space-x-2 bg-transparent hover:bg-zinc-900 text-zinc-100 hover:text-white border border-zinc-700 hover:border-zinc-500 font-bold px-8 py-4 rounded-xl transition-all text-base cursor-pointer"
              >
                <span>Voir mon Portfolio</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Trust points */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-6 border-t border-zinc-900">
              <div className="flex items-center space-x-2 text-xs text-zinc-400">
                <CheckCircle className="w-4 h-4 text-red-500 shrink-0" />
                <span>Doublement de conversion</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-zinc-400">
                <Shield className="w-4 h-4 text-red-500 shrink-0" />
                <span>Pixel & API 100% fonctionnels</span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-zinc-400">
                <Zap className="w-4 h-4 text-red-500 shrink-0" />
                <span>Livraison rapide en 48/72H</span>
              </div>
            </div>

          </div>

          {/* Right Column - Premium Live-Interactive CSS Mockup representation */}
          <div className="lg:col-span-5 relative mt-8 lg:mt-0">
            {/* Behind layout styling */}
            <div className="absolute inset-0 bg-red-600/20 rounded-3xl filter blur-2xl opacity-50 -z-10 animate-pulse" />
            
            {/* Interactive Looking Showcase Window */}
            <div className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden">
              
              {/* Header Bar */}
              <div className="bg-zinc-950/80 px-4 py-3 border-b border-zinc-800 flex items-center justify-between">
                <div className="flex space-x-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-zinc-700" />
                  <div className="w-3 h-3 rounded-full bg-zinc-800" />
                </div>
                <div className="bg-zinc-900 px-3 py-1 rounded-md border border-zinc-800/80 text-[10px] text-zinc-400 flex items-center space-x-1.5 max-w-[200px] truncate font-mono">
                  <Globe className="w-2.5 h-2.5 text-zinc-500 shrink-0" />
                  <span>elk-digital.com/landing-demo</span>
                </div>
                <div className="w-4 h-4" /> {/* Spacer */}
              </div>

              {/* Simulated Responsive Landing page inside mockup */}
              <div className="p-5 space-y-4 max-h-[380px] overflow-y-auto custom-scrollbar text-xs bg-zinc-950 text-zinc-300">
                
                {/* Simulated Sticky Bar */}
                <div className="bg-red-600/10 border border-red-500/20 rounded-lg p-2.5 flex items-center justify-between text-[11px]">
                  <span className="font-bold text-red-400">🔥 Offre Spéciale -50%</span>
                  <span className="bg-red-600 text-white font-extrabold px-2 py-0.5 rounded text-[9px] uppercase animate-pulse">
                    Commande Rapide
                  </span>
                </div>

                {/* Simulated Hero image and pricing */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-3 flex flex-col justify-center items-center text-center">
                    <div className="w-12 h-12 rounded bg-zinc-800/50 flex items-center justify-center border border-zinc-700 text-lg">
                      📱
                    </div>
                    <span className="text-[10px] text-zinc-400 mt-2">Smart Gadget Pro</span>
                    <span className="font-black text-red-500 mt-1">299 DH <span className="text-[9px] line-through text-zinc-500">598 DH</span></span>
                  </div>

                  <div className="space-y-2 flex flex-col justify-center">
                    <div className="flex items-center space-x-1 text-amber-500 text-[10px]">
                      <span>⭐⭐⭐⭐⭐</span>
                      <span className="text-zinc-400">(142)</span>
                    </div>
                    <p className="font-extrabold text-white text-xs leading-tight">
                      Nettoyeur à Ultra-sons Intelligent Haute Vitesse 2026
                    </p>
                    <p className="text-[10px] text-zinc-500 leading-snug">
                      Nettoyage en 30 secondes pour lunettes, bijoux & montres.
                    </p>
                  </div>
                </div>

                {/* Fast Checkout Form - Essential for Moroccan COD E-commerce */}
                <div className="bg-zinc-900 p-3.5 rounded-lg border border-zinc-800/80 space-y-2.5">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-1.5">
                    <span className="font-bold text-white uppercase text-[10px] tracking-wider flex items-center gap-1">
                      <ShoppingCart className="w-3 h-3 text-red-500" />
                      Formulaire d'Achat (COD)
                    </span>
                    <span className="text-[9px] text-green-500 font-semibold">Paiement à la livraison</span>
                  </div>

                  <div className="space-y-1.5">
                    <div>
                      <label className="text-[9px] text-zinc-400 block mb-0.5">Nom Complet *</label>
                      <input type="text" disabled placeholder="Ex: Mohamed Alami" className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1 text-[10px] text-zinc-300 pointer-events-none" />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[9px] text-zinc-400 block mb-0.5">Téléphone *</label>
                        <input type="text" disabled placeholder="06 XX XX XX XX" className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1 text-[10px] text-zinc-300 pointer-events-none" />
                      </div>
                      <div>
                        <label className="text-[9px] text-zinc-400 block mb-0.5">Ville *</label>
                        <input type="text" disabled placeholder="Ex: Casablanca" className="w-full bg-zinc-950 border border-zinc-800 rounded px-2 py-1 text-[10px] text-zinc-300 pointer-events-none" />
                      </div>
                    </div>
                  </div>

                  <button type="button" className="w-full bg-green-600 text-white font-extrabold py-2 rounded uppercase text-[10px] tracking-wider flex items-center justify-center space-x-1.5 shadow-md shadow-green-600/10 pointer-events-none">
                    <span>Acheter Maintenant (Paiement à Réception)</span>
                  </button>
                  <p className="text-[9px] text-center text-zinc-500">
                    🔒 Vos données sont sécurisées. Livraison gratuite 24/48h.
                  </p>
                </div>

                {/* Pixel Success Event Simulator */}
                <div className="bg-zinc-900 border border-red-900/30 p-2.5 rounded-lg flex items-center justify-between text-[9px] text-zinc-400 font-mono">
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-green-500 animate-ping" />
                    <span className="text-zinc-300">Facebook Pixel & TikTok API:</span>
                  </div>
                  <span className="text-green-400 font-bold">Event "Purchase" Fired Successfully (100% iOS 14+ Accurate)</span>
                </div>

              </div>

            </div>

            {/* Floating Trust Badge */}
            <div className="absolute -bottom-6 -left-6 bg-zinc-900 border border-zinc-800 p-4 rounded-xl shadow-xl flex items-center space-x-3 max-w-[210px]">
              <div className="w-10 h-10 rounded-full bg-red-600/10 border border-red-500 flex items-center justify-center text-red-500 font-extrabold text-sm shrink-0">
                100%
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">Vitesse Optimale</h4>
                <p className="text-[10px] text-zinc-400">Moteurs YouCan/Shopify tunés pour charger en &lt; 1.2s</p>
              </div>
            </div>

          </div>

        </div>

        {/* Counter Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-20 pt-10 border-t border-zinc-900">
          <div className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-2xl text-center md:text-left">
            <p className="text-3xl sm:text-4xl font-black text-white">
              120<span className="text-red-500">+</span>
            </p>
            <p className="text-xs text-zinc-400 font-medium mt-1 uppercase tracking-wider">Projets Livrés</p>
          </div>
          <div className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-2xl text-center md:text-left">
            <p className="text-3xl sm:text-4xl font-black text-white">
              +18<span className="text-red-500">%</span>
            </p>
            <p className="text-xs text-zinc-400 font-medium mt-1 uppercase tracking-wider">Augmentation Conversion</p>
          </div>
          <div className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-2xl text-center md:text-left">
            <p className="text-3xl sm:text-4xl font-black text-white">
              48<span className="text-red-500">h</span>
            </p>
            <p className="text-xs text-zinc-400 font-medium mt-1 uppercase tracking-wider">Temps Moyen de Livraison</p>
          </div>
          <div className="p-4 bg-zinc-900/40 border border-zinc-900 rounded-2xl text-center md:text-left">
            <p className="text-3xl sm:text-4xl font-black text-white">
              99<span className="text-red-500">%</span>
            </p>
            <p className="text-xs text-zinc-400 font-medium mt-1 uppercase tracking-wider">Taux de Satisfaction Client</p>
          </div>
        </div>

      </div>
    </section>
  );
}
