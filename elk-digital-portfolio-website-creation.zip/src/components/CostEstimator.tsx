import { useState } from "react";
import { Calculator, MessageSquare, Sparkles, PhoneCall } from "lucide-react";

interface Addon {
  id: string;
  name: string;
  priceMAD: number;
  description: string;
}

export default function CostEstimator() {
  const [projectType, setProjectType] = useState<string>("landing-page");
  const [selectedAddons, setSelectedAddons] = useState<string[]>(["pixel-api"]);

  const baseProjects = [
    {
      id: "landing-page",
      name: "Landing Page Monoproduit (Haute Conversion)",
      priceMAD: 1500,
      description: "Parfait pour vendre un produit spécifique avec un taux de conversion maximal.",
      platform: "Custom HTML/CSS ou YouCan/Shopify"
    },
    {
      id: "youcan-store",
      name: "Boutique Complète YouCan VIP",
      priceMAD: 1900,
      description: "Store complet configuré, pack produits, design professionnel et optimisé COD.",
      platform: "YouCan"
    },
    {
      id: "shopify-store",
      name: "Boutique Premium Shopify",
      priceMAD: 2900,
      description: "Store Shopify haut de gamme, thème premium inclus, applications d'upsell.",
      platform: "Shopify"
    },
    {
      id: "wordpress-site",
      name: "Site Showcase WordPress Professionnel",
      priceMAD: 3200,
      description: "Site vitrine pour agences immobilières, services locaux ou corporate.",
      platform: "WordPress"
    }
  ];

  const addons: Addon[] = [
    {
      id: "pixel-api",
      name: "Intégration Conversions API (iOS 14+ Bypass)",
      priceMAD: 500,
      description: "Liez vos serveurs publicitaires (Facebook/TikTok) sans aucune perte de données."
    },
    {
      id: "copywriting",
      name: "Copywriting de Vente (Darija / Français)",
      priceMAD: 400,
      description: "Rédaction persuasive et hypnotique de votre page produit pour capter l'intérêt."
    },
    {
      id: "fast-delivery",
      name: "Livraison Express en 48 Heures",
      priceMAD: 500,
      description: "Votre projet passe en priorité absolue pour être livré en un temps record."
    },
    {
      id: "upsell-setup",
      name: "Configuration d'un Entonnoir d'Upsell / Cross-sell",
      priceMAD: 600,
      description: "Doublez la valeur moyenne du panier de vos clients grâce aux offres additionnelles."
    }
  ];

  const handleAddonToggle = (addonId: string) => {
    if (selectedAddons.includes(addonId)) {
      setSelectedAddons(selectedAddons.filter(id => id !== addonId));
    } else {
      setSelectedAddons([...selectedAddons, addonId]);
    }
  };

  const currentProject = baseProjects.find(p => p.id === projectType) || baseProjects[0];
  const addonsTotal = addons
    .filter(a => selectedAddons.includes(a.id))
    .reduce((sum, a) => sum + a.priceMAD, 0);

  const totalMAD = currentProject.priceMAD + addonsTotal;
  const totalUSD = Math.round(totalMAD / 10); // Simple conversion rate ~10 MAD = 1 USD

  const generateWhatsAppMessage = () => {
    const activeProject = currentProject.name;
    const activeAddonsList = addons
      .filter(a => selectedAddons.includes(a.id))
      .map(a => `   - ${a.name} (+${a.priceMAD} DH)`)
      .join("\n");
    
    const message = `Bonjour Amine (ELK-DIGITAL),\n\nJe viens de tester votre simulateur de devis en ligne et je suis intéressé par vos services :\n\n*Projet de Base :* ${activeProject} (${currentProject.priceMAD} DH)\n\n*Options Choisies :*\n${activeAddonsList || "   - Aucune option supplémentaire"}\n\n*Estimation Totale :* ~${totalMAD} DH (${totalUSD} USD)\n\nPourriez-vous me recontacter pour discuter du lancement de ce projet ? Merci !`;
    
    return encodeURIComponent(message);
  };

  return (
    <section id="estimator" className="py-24 bg-zinc-900/40 border-b border-zinc-900 relative">
      <div className="absolute top-0 left-1/4 w-72 h-72 bg-red-600/5 rounded-full blur-[130px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Title Section */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
          <div className="inline-block bg-red-600/10 border border-red-500/20 text-red-400 font-mono font-bold text-xs uppercase px-3.5 py-1 rounded-full">
            Calculateur de Budget en Ligne
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Estimez Le Prix De <span className="text-red-500">Votre Futur Projet</span>
          </h2>
          <p className="text-zinc-400 text-sm sm:text-base">
            Sélectionnez votre type de projet et cochez les options requises. Vous obtiendrez un prix approximatif instantané que vous pourrez m'envoyer directement par WhatsApp.
          </p>
        </div>

        {/* Calculator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Side: Choices */}
          <div className="lg:col-span-7 space-y-8 text-left bg-zinc-950 p-6 sm:p-8 rounded-2xl border border-zinc-800/80">
            
            {/* Step 1: Base Project */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold uppercase tracking-wider text-red-500 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-red-600/15 border border-red-500 text-red-500 flex items-center justify-center font-mono text-[10px]">1</span>
                Choisissez le projet de base
              </h3>

              <div className="space-y-3">
                {baseProjects.map((project) => (
                  <label
                    key={project.id}
                    className={`block p-4 rounded-xl border transition-all cursor-pointer ${
                      projectType === project.id
                        ? "bg-red-600/5 border-red-500 shadow-md shadow-red-600/5"
                        : "bg-zinc-900/60 border-zinc-800/80 hover:border-zinc-700 hover:bg-zinc-900"
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <input
                          type="radio"
                          name="projectType"
                          value={project.id}
                          checked={projectType === project.id}
                          onChange={() => setProjectType(project.id)}
                          className="accent-red-600 w-4 h-4 text-red-600 bg-zinc-950 border-zinc-800 cursor-pointer focus:ring-0 focus:ring-offset-0"
                        />
                        <div>
                          <p className="font-extrabold text-white text-sm sm:text-base">{project.name}</p>
                          <p className="text-[11px] text-zinc-500 mt-0.5">{project.description}</p>
                        </div>
                      </div>
                      <span className="text-red-500 font-black text-xs sm:text-sm shrink-0 ml-4 font-mono">
                        {project.priceMAD} DH
                      </span>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Step 2: Addons */}
            <div className="space-y-4 pt-4 border-t border-zinc-900">
              <h3 className="text-sm font-bold uppercase tracking-wider text-red-500 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-red-600/15 border border-red-500 text-red-500 flex items-center justify-center font-mono text-[10px]">2</span>
                Cochez des options d'optimisation
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {addons.map((addon) => {
                  const isChecked = selectedAddons.includes(addon.id);
                  return (
                    <div
                      key={addon.id}
                      onClick={() => handleAddonToggle(addon.id)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                        isChecked
                          ? "bg-red-600/5 border-red-500 shadow-md"
                          : "bg-zinc-900/40 border-zinc-800/80 hover:border-zinc-700/80"
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-start justify-between gap-2">
                          <span className={`text-xs font-extrabold ${isChecked ? "text-red-400" : "text-white"}`}>
                            {addon.name}
                          </span>
                          <span className="text-red-500 font-extrabold text-[11px] font-mono shrink-0">
                            +{addon.priceMAD} DH
                          </span>
                        </div>
                        <p className="text-[10px] text-zinc-500 leading-snug">
                          {addon.description}
                        </p>
                      </div>
                      <div className="flex items-center space-x-1.5 mt-3 self-end">
                        <span className={`w-3.5 h-3.5 rounded flex items-center justify-center border text-[9px] ${
                          isChecked ? "bg-red-600 border-red-500 text-white" : "border-zinc-700 bg-zinc-950"
                        }`}>
                          {isChecked && "✓"}
                        </span>
                        <span className="text-[10px] text-zinc-400 font-semibold">Inclure</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Right Side: Dynamically Updated Pricing Card */}
          <div className="lg:col-span-5 lg:sticky lg:top-24 space-y-6">
            
            <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden text-left">
              
              {/* Background gradient block */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-xl pointer-events-none" />

              <div className="flex items-center space-x-2 text-zinc-400 text-xs font-bold uppercase tracking-wider mb-6">
                <Calculator className="w-4 h-4 text-red-500" />
                <span>Résumé du devis</span>
              </div>

              {/* Selected Items details breakdown */}
              <div className="space-y-4 mb-6 border-b border-zinc-900 pb-6 text-xs text-zinc-400">
                <div className="flex justify-between items-start gap-4">
                  <div>
                    <span className="font-extrabold text-white block">Formule Base :</span>
                    <span className="text-[11px] text-zinc-500 truncate max-w-[200px] block">{currentProject.name}</span>
                  </div>
                  <span className="font-mono text-zinc-300 font-bold shrink-0">{currentProject.priceMAD} DH</span>
                </div>

                {selectedAddons.length > 0 && (
                  <div className="space-y-2">
                    <span className="font-extrabold text-white block">Options Activées :</span>
                    {addons
                      .filter(a => selectedAddons.includes(a.id))
                      .map(a => (
                        <div key={a.id} className="flex justify-between items-center text-[11px] text-zinc-500 pl-2 border-l border-red-500/30">
                          <span className="truncate max-w-[180px]">{a.name}</span>
                          <span className="font-mono font-semibold shrink-0">+{a.priceMAD} DH</span>
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {/* Huge Live total */}
              <div className="space-y-1 mb-8">
                <span className="text-zinc-500 text-[10px] uppercase font-bold tracking-widest block">
                  Tarif Estimé Clés En Main :
                </span>
                <div className="flex items-baseline space-x-2">
                  <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
                    {totalMAD} <span className="text-red-500">DH</span>
                  </span>
                  <span className="text-zinc-400 text-xs font-semibold">
                    (~{totalUSD} USD)
                  </span>
                </div>
                <span className="text-[10px] text-zinc-500 block leading-snug">
                  * Hors coûts d'abonnement Shopify / nom de domaine du store. Hébergement de base inclus gratuitement.
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3">
                <a
                  href={`https://wa.me/212620490769?text=${generateWhatsAppMessage()}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-extrabold text-sm py-4 rounded-xl transition-all flex items-center justify-center space-x-2 cursor-pointer uppercase tracking-wider shadow-lg shadow-red-600/20 hover:-translate-y-0.5"
                >
                  <MessageSquare className="w-4.5 h-4.5" />
                  <span>Envoyer Devis Par WhatsApp</span>
                </a>

                <a
                  href="tel:0620490769"
                  className="w-full bg-transparent hover:bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white font-bold text-xs py-3 rounded-xl transition-all flex items-center justify-center space-x-2"
                >
                  <PhoneCall className="w-3.5 h-3.5 text-red-500" />
                  <span>Ou m'appeler directement</span>
                </a>
              </div>

              {/* Fast Delivery Assurance badge */}
              <div className="mt-6 pt-4 border-t border-zinc-900 flex items-center space-x-3 text-xs text-zinc-400">
                <div className="w-8 h-8 rounded bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-500 font-extrabold text-[10px]">
                  OK
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-[11px]">Garantie Sans Risque</h4>
                  <p className="text-[10px] text-zinc-500">Vous ne payez l'acompte qu'après validation de la maquette.</p>
                </div>
              </div>

            </div>

            {/* Satisfaction Trigger */}
            <div className="bg-zinc-950/60 border border-zinc-900 p-5 rounded-2xl flex items-center space-x-3.5 text-left">
              <Sparkles className="w-5 h-5 text-red-500 shrink-0" />
              <p className="text-xs text-zinc-400 leading-snug">
                Vous avez un budget fixe ou un besoin différent ? <a href="mailto:elkousm676@gmail.com" className="text-red-400 hover:underline font-bold">Écrivez-moi par email</a> pour que nous puissions bâtir un plan sur-mesure.
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
