import { Star, MessageSquare, Quote } from "lucide-react";

export default function Testimonials() {
  const reviews = [
    {
      name: "Rachid El Alami",
      role: "E-commerçant COD Maroc",
      location: "Casablanca",
      niche: "Niche Cosmétique",
      stars: 5,
      content: "Amine a développé ma landing page YouCan pour une huile de massage haut de gamme. Le résultat est incroyable ! Mon taux de conversion est passé de 2.1% à 6.3% sur Facebook Ads, et la vitesse de chargement est stupéfiante. Je le recommande vivement à tous les vendeurs de COD."
    },
    {
      name: "Sarah Dumont",
      role: "CEO de Bio-Saffron France",
      location: "Paris / Marrakech",
      niche: "Produits de Luxe",
      stars: 5,
      content: "Je voulais une boutique Shopify qui fasse professionnelle et artisanale à la fois pour vendre du safran bio marocain. Amine a configuré un thème VIP magnifique avec des animations fluides et une intégration parfaite des pixels TikTok/Meta. Les ventes ont commencé dès le premier jour."
    },
    {
      name: "Youssef Bennani",
      role: "Dropshipper & Vendeur YouCan",
      location: "Marrakech",
      niche: "Appareils Électroménagers",
      stars: 5,
      content: "Franchement, le meilleur développeur au Maroc avec qui j'ai travaillé. Très réactif sur WhatsApp, il m'a fait économiser des dizaines de dollars d'applications YouCan en injectant du code sur-mesure pour les avis, le stock d'urgence et le sélecteur de villes. Top service !"
    },
    {
      name: "Imane Safir",
      role: "Fondatrice de Safir Artisanal",
      location: "Fès / Safi",
      niche: "Artisanat d'Exportation",
      stars: 5,
      content: "J'avais besoin d'un site vitrine haut de gamme sans CMS lourd pour exposer nos poteries faites main à l'international. Amine a codé le site de A à Z en HTML/CSS/JS. Il est hébergé gratuitement sur GitHub, ultra sécurisé et les clients américains adorent l'expérience de navigation !"
    }
  ];

  return (
    <section className="bg-zinc-900/40 py-24 border-b border-zinc-900 relative">
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-72 h-72 bg-red-600/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-left">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-block bg-red-600/10 border border-red-500/20 text-red-400 font-mono font-bold text-xs uppercase px-3.5 py-1 rounded-full">
              Ce Qu'ils Disent De Moi
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Témoignages De <span className="text-red-500">Clients Satisfaits</span>
            </h2>
            <p className="text-zinc-400 text-sm sm:text-base">
              Rien n'est plus gratifiant que d'aider des entrepreneurs marocains et internationaux à transformer leur trafic publicitaire en ventes réelles. Voici quelques retours d'expérience.
            </p>
          </div>
          
          <div className="hidden md:flex items-center space-x-2 text-zinc-400 text-xs font-semibold bg-zinc-900/80 border border-zinc-800 px-4 py-2.5 rounded-xl self-start">
            <MessageSquare className="w-4 h-4 text-red-500" />
            <span>Moyenne générale : 5.0 / 5 (30+ avis)</span>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {reviews.map((rev, index) => (
            <div
              key={index}
              className="bg-zinc-950 border border-zinc-800/80 rounded-2xl p-6 sm:p-8 relative flex flex-col justify-between group hover:border-red-500/20 transition-all duration-300"
            >
              <Quote className="absolute top-6 right-6 w-10 h-10 text-red-600/5 group-hover:text-red-600/10 transition-colors" />

              <div className="space-y-4">
                {/* Rating stars */}
                <div className="flex space-x-1">
                  {[...Array(rev.stars)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-red-500 text-red-500" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed italic">
                  "{rev.content}"
                </p>
              </div>

              {/* Author Info */}
              <div className="flex items-center space-x-3 mt-6 pt-6 border-t border-zinc-900">
                <div className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center font-black text-xs text-white">
                  {rev.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-extrabold text-white">{rev.name}</h4>
                  <div className="flex items-center space-x-1.5 text-[10px] text-zinc-500 mt-0.5">
                    <span>{rev.role}</span>
                    <span>•</span>
                    <span className="text-red-500 font-semibold">{rev.location}</span>
                  </div>
                  <span className="inline-block bg-zinc-900 border border-zinc-800 text-zinc-400 font-mono text-[9px] px-2 py-0.5 rounded mt-1">
                    {rev.niche}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
