import { useState, useEffect } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Services from "./components/Services";
import Portfolio from "./components/Portfolio";
import CostEstimator from "./components/CostEstimator";
import WhyUs from "./components/WhyUs";
import Testimonials from "./components/Testimonials";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import { MessageSquare, ArrowUp, Zap } from "lucide-react";

export default function App() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavigate = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      // Offset scroll for sticky header
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-white font-sans selection:bg-red-600 selection:text-white antialiased overflow-x-hidden">
      
      {/* Sticky Header */}
      <Header onNavigate={handleNavigate} />

      {/* Main Content Sections */}
      <main>
        
        {/* Hero Banner */}
        <Hero onNavigate={handleNavigate} />

        {/* Services & Expertise */}
        <Services />

        {/* Portfolio & Live Simulated Interactive Demos */}
        <Portfolio />

        {/* Interactive Live Budget Calculator */}
        <CostEstimator />

        {/* Why Choose ELK-DIGITAL */}
        <WhyUs />

        {/* Client Testimonials */}
        <Testimonials />

        {/* Quick & Detailed Contact Form */}
        <Contact />

      </main>

      {/* Footer Branding & deployment documentation */}
      <Footer onNavigate={handleNavigate} />

      {/* Persistent Floating Widgets */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col space-y-3 items-end">
        
        {/* Floating Urgency Promo Callout (Darija/French) */}
        <div className="hidden sm:flex items-center space-x-2 bg-black/90 border border-zinc-800 text-zinc-300 rounded-full py-1.5 px-3 shadow-2xl backdrop-blur-md animate-pulse">
          <Zap className="w-3.5 h-3.5 text-red-500" />
          <span className="text-[10px] font-bold">Lancement d'activité ? Devis gratuit en 30 min !</span>
        </div>

        <div className="flex space-x-3 items-center">
          
          {/* Scroll to Top Button */}
          {showScrollTop && (
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="w-12 h-12 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white flex items-center justify-center border border-zinc-800 hover:border-zinc-700 transition-all shadow-xl cursor-pointer"
              title="Retour en haut"
            >
              <ArrowUp className="w-5 h-5" />
            </button>
          )}

          {/* Premium Floating Glowing WhatsApp Button */}
          <a
            href="https://wa.me/212620490769?text=Bonjour%20Amine%2C%20je%20suis%20sur%20votre%20site%20ELK-DIGITAL%20et%20je%20souhaite%20lancer%20un%20projet%20web."
            target="_blank"
            rel="noopener noreferrer"
            className="w-14 h-14 rounded-full bg-green-600 hover:bg-green-500 text-white flex items-center justify-center shadow-2xl shadow-green-600/30 hover:scale-110 transition-all duration-300 relative group"
            title="Chatter sur WhatsApp"
          >
            {/* Pulsing ring */}
            <span className="absolute inset-0 rounded-full bg-green-500/40 animate-ping opacity-75" />
            <MessageSquare className="w-7 h-7 relative z-10" />
            
            {/* Tooltip on Hover */}
            <span className="absolute right-16 bg-black border border-zinc-800 text-white text-[10px] font-bold py-1.5 px-3 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 whitespace-nowrap shadow-xl">
              Dima Online - Discuter sur WhatsApp
            </span>
          </a>

        </div>

      </div>

    </div>
  );
}
